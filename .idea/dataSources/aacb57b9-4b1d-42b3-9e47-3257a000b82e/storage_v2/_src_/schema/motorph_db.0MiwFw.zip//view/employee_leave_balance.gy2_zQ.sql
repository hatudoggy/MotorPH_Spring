create definer = admin@`%` view employee_leave_balance as
select `motorph_db`.`employee`.`employee_id`                        AS `employee_id`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 1))) AS `absence`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 2))) AS `sick`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 3))) AS `vacation`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 4))) AS `maternity`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 5))) AS `paternity`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 6))) AS `emergency`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 7))) AS `paternal`,
       (select `motorph_db`.`leave_balance`.`balance`
        from `motorph_db`.`leave_balance`
        where ((`motorph_db`.`leave_balance`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`leave_balance`.`leave_type_id` = 8))) AS `bereavement`
from (`motorph_db`.`leave_balance` join `motorph_db`.`employee`
      on ((`motorph_db`.`employee`.`employee_id` = `motorph_db`.`leave_balance`.`employee_id`)))
group by `motorph_db`.`leave_balance`.`employee_id`
order by `motorph_db`.`leave_balance`.`employee_id`;

