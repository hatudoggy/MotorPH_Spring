create definer = admin@`%` view employee_leave as
select concat(date_format(`motorph_db`.`leave_request`.`request_date`, '%Y%m%d'),
              row_number() OVER (PARTITION BY `motorph_db`.`leave_request`.`request_date` ORDER BY `motorph_db`.`leave_request`.`leave_request_id` )) AS `leave_request_id`,
       `motorph_db`.`leave_request`.`employee_id`                                                                                                     AS `employee_id`,
       `motorph_db`.`leave_request`.`request_date`                                                                                                    AS `request_date`,
       `motorph_db`.`leave_status`.`status`                                                                                                           AS `status`,
       concat(`motorph_db`.`employee`.`last_name`, ', ',
              `motorph_db`.`employee`.`first_name`)                                                                                                   AS `employee_name`,
       (case
            when (`motorph_db`.`employee_job_details`.`supervisor_id` = `motorph_db`.`employee`.`employee_id`)
                then 'None'
            else concat(`supervisor`.`last_name`, ', ', `supervisor`.`first_name`) end)                                                               AS `supervisor_name`,
       `motorph_db`.`leave_type`.`type`                                                                                                               AS `type`,
       date_format(`motorph_db`.`leave_request`.`start_date`, '%b %e, %Y')                                                                            AS `start_date`,
       date_format(`motorph_db`.`leave_request`.`end_date`, '%b %e, %Y')                                                                              AS `end_date`,
       ((to_days(`motorph_db`.`leave_request`.`end_date`) - to_days(`motorph_db`.`leave_request`.`start_date`)) +
        1)                                                                                                                                            AS `total_days`,
       `motorph_db`.`leave_request`.`reason`                                                                                                          AS `reason`
from ((((((`motorph_db`.`leave_request` join `motorph_db`.`employee` on ((`motorph_db`.`leave_request`.`employee_id` =
                                                                          `motorph_db`.`employee`.`employee_id`))) join `motorph_db`.`leave_type`
          on ((`motorph_db`.`leave_request`.`leave_type_id` =
               `motorph_db`.`leave_type`.`leave_type_id`))) join `motorph_db`.`leave_status`
         on ((`motorph_db`.`leave_request`.`leave_status_id` =
              `motorph_db`.`leave_status`.`leave_status_id`))) join `motorph_db`.`employee_job_details`
        on ((`motorph_db`.`leave_request`.`employee_id` =
             `motorph_db`.`employee_job_details`.`employee_id`))) join `motorph_db`.`employee` `supervisor`
       on ((`motorph_db`.`employee_job_details`.`supervisor_id` =
            `supervisor`.`employee_id`))) join `motorph_db`.`employee` `supervisor_employee`
      on ((`supervisor`.`employee_id` = `supervisor_employee`.`employee_id`)));

