create definer = admin@`%` view employee_benefits as
select concat(`e`.`last_name`, ', ', `e`.`first_name`) AS `employee_name`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where (`motorph_db`.`benefits`.`benefit_type_id` = 1)
        limit 1)                                       AS `rice_subsidy`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where (`motorph_db`.`benefits`.`benefit_type_id` = 2)
        limit 1)                                       AS `phone_allowance`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where (`motorph_db`.`benefits`.`benefit_type_id` = 3)
        limit 1)                                       AS `clothing_allowance`
from (`motorph_db`.`benefits` `b` join `motorph_db`.`employee` `e` on ((`b`.`employee_id` = `e`.`employee_id`)))
group by `employee_name`
order by `employee_name`;

