create definer = admin@`%` view employee_full_details as
select `motorph_db`.`employee`.`employee_id`                             AS `employee_id`,
       `motorph_db`.`employee`.`last_name`                               AS `last_name`,
       `motorph_db`.`employee`.`first_name`                              AS `first_name`,
       `motorph_db`.`employee`.`dob`                                     AS `dob`,
       `motorph_db`.`employee`.`address`                                 AS `address`,
       `motorph_db`.`employee_contact`.`contact_no`                      AS `contact_no`,
       `gov_id`.`sss_no`                                                 AS `sss_no`,
       `gov_id`.`phil_health_no`                                         AS `phil_health_no`,
       `gov_id`.`pag_ibig_no`                                            AS `pag_ibig_no`,
       `gov_id`.`tin_no`                                                 AS `tin_no`,
       `motorph_db`.`department`.`department_name`                       AS `department_name`,
       `motorph_db`.`position`.`position_name`                           AS `position_name`,
       concat(`supervisor`.`last_name`, ', ', `supervisor`.`first_name`) AS `supervisor_name`,
       `motorph_db`.`employment_status`.`status_name`                    AS `status_name`,
       `s`.`basic_salary`                                                AS `basic_salary`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` = 1))
        limit 1)                                                         AS `rice_subsidy`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` = 2))
        limit 1)                                                         AS `phone_allowance`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `motorph_db`.`employee`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` = 3))
        limit 1)                                                         AS `clothing_allowance`
from (((((((((`motorph_db`.`employee` join `motorph_db`.`employee_contact`
              on ((`motorph_db`.`employee_contact`.`employee_id` =
                   `motorph_db`.`employee`.`employee_id`))) join `motorph_db`.`employee_government_ids` `gov_id`
             on ((`gov_id`.`employee_id` = `motorph_db`.`employee`.`employee_id`))) join `motorph_db`.`employee_job_details` `job`
            on ((`motorph_db`.`employee`.`employee_id` = `job`.`employee_id`))) join `motorph_db`.`position`
           on ((`motorph_db`.`position`.`position_code` = `job`.`position_code`))) join `motorph_db`.`department`
          on ((`motorph_db`.`department`.`department_code` = `job`.`department_code`))) join `motorph_db`.`employment_status`
         on ((`motorph_db`.`employment_status`.`status_id` = `job`.`status_id`))) join `motorph_db`.`employee` `supervisor`
        on ((`job`.`supervisor_id` = `supervisor`.`employee_id`))) join `motorph_db`.`employee` `supervisor_employee`
       on ((`supervisor`.`employee_id` = `supervisor_employee`.`employee_id`))) join `motorph_db`.`salary` `s`
      on ((`s`.`salary_id` = `motorph_db`.`employee`.`employee_id`)))
order by `motorph_db`.`employee`.`employee_id`;

