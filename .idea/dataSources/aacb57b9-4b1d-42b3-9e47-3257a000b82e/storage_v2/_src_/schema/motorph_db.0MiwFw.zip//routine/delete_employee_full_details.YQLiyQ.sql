create
    definer = admin@`%` procedure delete_employee_full_details(IN p_employee_id int)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;

  -- Delete from benefits table
  DELETE FROM benefits WHERE employee_id = p_employee_id;

  -- Delete from salary table
  DELETE FROM salary WHERE employee_id = p_employee_id;

  -- Delete from employee_job_details table
  DELETE FROM employee_job_details WHERE employee_id = p_employee_id;

  -- Delete from employee_government_ids table
  DELETE FROM employee_government_ids WHERE employee_id = p_employee_id;

  -- Delete from employee_contact table
  DELETE FROM employee_contact WHERE employee_id = p_employee_id;

  -- Delete from employee table
  DELETE FROM employee WHERE employee_id = p_employee_id;

  COMMIT;
END;

