create
    definer = admin@`%` procedure update_employee_full_details(IN p_employee_id int, IN p_last_name varchar(255),
                                                               IN p_first_name varchar(255), IN p_date_of_birth date,
                                                               IN p_address varchar(255), IN p_contact_no varchar(20),
                                                               IN p_sss_no varchar(20), IN p_philhealth_no varchar(20),
                                                               IN p_pagibig_no varchar(20), IN p_tin_no varchar(20),
                                                               IN p_department_name varchar(255),
                                                               IN p_position_name varchar(255),
                                                               IN p_supervisor_name varchar(255),
                                                               IN p_status varchar(15), IN p_basic_salary decimal(8, 2),
                                                               IN p_rice_subsidy decimal(10, 2),
                                                               IN p_phone_allowance decimal(10, 2),
                                                               IN p_clothing_allowance decimal(10, 2),
                                                               IN p_semi_monthly decimal(10, 2),
                                                               IN p_hourly_rate decimal(5, 2))
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;

  -- Update employee table
  UPDATE employee
  SET last_name = p_last_name, first_name = p_first_name, date_of_birth = p_date_of_birth, address = p_address
  WHERE employee_id = p_employee_id;

  -- Update employee_contact table
  UPDATE employee_contact
  SET contact_no = p_contact_no
  WHERE employee_id = p_employee_id;

  -- Update employee_government_ids table
  UPDATE employee_government_ids
  SET sss_no = p_sss_no, philhealth_no = p_philhealth_no, pagibig_no = p_pagibig_no, tin_no = p_tin_no
  WHERE employee_id = p_employee_id;

  -- Insert into department table if not exists
  IF NOT EXISTS (SELECT 1 FROM department WHERE department_name = p_department_name) THEN
    INSERT INTO department (department_name) VALUES (p_department_name);
  END IF;

  -- Get the department_code
  SET @department_code = (SELECT department_code FROM department WHERE department_name = p_department_name);

  -- Insert into position table if not exists
  IF NOT EXISTS (SELECT 1 FROM position WHERE position_name = p_position_name) THEN
    INSERT INTO position (position_name) VALUES (p_position_name);
  END IF;

  -- Get the position_code
  SET @position_code = (SELECT position_code FROM position WHERE position_name = p_position_name);

  -- Update employee_job_details table
  UPDATE employee_job_details
  SET supervisor_id = (SELECT employee_id FROM employee WHERE CONCAT(last_name, ', ', first_name) = p_supervisor_name),
      department_code = @department_code, position_code = @position_code, status_id = (SELECT status_id FROM employment_status WHERE status = p_status)
  WHERE employee_id = p_employee_id;

  -- Update salary table
  UPDATE salary
  SET basic_salary = p_basic_salary, hourly_rate = p_hourly_rate
  WHERE employee_id = p_employee_id;

  -- Update benefits table
  UPDATE benefits
  SET amount = CASE
                WHEN benefit_type_id = 1 THEN p_rice_subsidy
                WHEN benefit_type_id = 2 THEN p_phone_allowance
                WHEN benefit_type_id = 3 THEN p_clothing_allowance
              END
  WHERE employee_id = p_employee_id;

  COMMIT;
END;

