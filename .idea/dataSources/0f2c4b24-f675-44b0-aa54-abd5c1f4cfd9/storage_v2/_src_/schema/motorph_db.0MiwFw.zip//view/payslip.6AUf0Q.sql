create definer = admin@`%` view payslip as
select concat(`e`.`employee_id`, '-', cast(`p`.`period_start` as date), '-',
              dayofmonth(`p`.`period_end`))                                                         AS `payslip_id`,
       `e`.`employee_id`                                                                            AS `employee_id`,
       concat(`e`.`last_name`, ', ', `e`.`first_name`)                                              AS `employee_name`,
       date_format(`p`.`period_start`, '%b %e, %Y')                                                 AS `period_start`,
       date_format(`p`.`period_end`, '%b %e, %Y')                                                   AS `period_end`,
       concat(`pos_dep`.`position_name`, ' / ',
              `pos_dep`.`department_name`)                                                          AS `position_department`,
       (select count(`motorph_db`.`attendance`.`date`)
        from `motorph_db`.`attendance`
        where ((`motorph_db`.`attendance`.`employee_id` = `e`.`employee_id`) and
               (`motorph_db`.`attendance`.`date` between `p`.`period_start` and `p`.`period_end`))) AS `days_worked`,
       `p`.`monthly_rate`                                                                           AS `monthly_rate`,
       `p`.`daily_rate`                                                                             AS `daily_rate`,
       `p`.`overtime_pay`                                                                           AS `overtime_pay`,
       `p`.`gross_income`                                                                           AS `gross_income`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `p`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` = 1)))                                    AS `rice_subsidy`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `p`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` = 2)))                                    AS `phone_allowance`,
       (select `motorph_db`.`benefits`.`amount`
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `p`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` = 3)))                                    AS `clothing_allowance`,
       (select coalesce(sum(`motorph_db`.`benefits`.`amount`), 0)
        from `motorph_db`.`benefits`
        where ((`motorph_db`.`benefits`.`employee_id` = `p`.`employee_id`) and
               (`motorph_db`.`benefits`.`benefit_type_id` in (1, 2, 3))))                           AS `total_benefits`,
       `motorph_db`.`pd`.`sss`                                                                      AS `sss`,
       `motorph_db`.`pd`.`philhealth`                                                               AS `philhealth`,
       `motorph_db`.`pd`.`pag_ibig`                                                                 AS `pag_ibig`,
       `motorph_db`.`pd`.`tax`                                                                      AS `tax`,
       (((`motorph_db`.`pd`.`sss` + `motorph_db`.`pd`.`philhealth`) + `motorph_db`.`pd`.`pag_ibig`) +
        `motorph_db`.`pd`.`tax`)                                                                    AS `total_deductions`,
       `p`.`net_pay`                                                                                AS `net_pay`
from (((`motorph_db`.`payroll` `p` join `motorph_db`.`employee` `e`
        on ((`p`.`employee_id` = `e`.`employee_id`))) join (select `motorph_db`.`employee_job_details`.`employee_id` AS `employee_id`,
                                                                   `motorph_db`.`position`.`position_name`           AS `position_name`,
                                                                   `motorph_db`.`department`.`department_name`       AS `department_name`
                                                            from ((`motorph_db`.`employee_job_details` join `motorph_db`.`position`
                                                                   on ((`motorph_db`.`position`.`position_code` =
                                                                        `motorph_db`.`employee_job_details`.`position_code`))) join `motorph_db`.`department`
                                                                  on ((`motorph_db`.`department`.`department_code` =
                                                                       `motorph_db`.`employee_job_details`.`department_code`)))) `pos_dep`
       on ((`pos_dep`.`employee_id` = `p`.`employee_id`))) join `motorph_db`.`payroll_deductions` `pd`
      on ((`p`.`payroll_id` = `motorph_db`.`pd`.`payroll_id`)))
order by concat(`e`.`employee_id`, '-', year(`p`.`period_start`), '-', dayofmonth(`p`.`period_start`), '-',
                dayofmonth(`p`.`period_end`));

