create definer = admin@`%` view user_login as
select `u`.`employee_id`     AS `employee_id`,
       `u`.`username`        AS `username`,
       `u`.`salt`            AS `salt`,
       `u`.`password`        AS `password`,
       `p`.`position_name`   AS `position_name`,
       `d`.`department_name` AS `department_name`,
       `r`.`role_name`       AS `role_name`,
       `u`.`created_at`      AS `created_at`,
       `u`.`last_modified`   AS `last_modified`
from ((((`motorph_db`.`user` `u` join `motorph_db`.`user_role` `r`
         on ((`u`.`role_id` = `r`.`user_role_id`))) join `motorph_db`.`employee_job_details` `j`
        on ((`u`.`employee_id` = `j`.`employee_id`))) join `motorph_db`.`position` `p`
       on ((`j`.`position_code` = `p`.`position_code`))) join `motorph_db`.`department` `d`
      on ((`j`.`department_code` = `d`.`department_code`)))
order by `u`.`employee_id`;

