create definer = admin@`%` trigger before_user_insert
    before insert
    on user_credentials
    for each row
BEGIN
	-- Generate a random salt
    SET NEW.salt = LEFT(MD5(RAND()), 16);
    -- Hash the password with the salt
    SET NEW.`password` = SHA2(CONCAT(NEW.salt, NEW.password), 256);
    -- Set the creation time
    SET NEW.created_at = CURRENT_TIMESTAMP;
    -- Set the last modified time
    SET NEW.last_modified = CURRENT_TIMESTAMP;
END;

