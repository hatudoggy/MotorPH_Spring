create definer = admin@`%` view payroll_deductions as
select `motorph_db`.`deductions`.`payroll_id`                                                  AS `payroll_id`,
       concat(`motorph_db`.`employee`.`last_name`, ', ', `motorph_db`.`employee`.`first_name`) AS `employee_name`,
       `motorph_db`.`employee_government_ids`.`sss_no`                                         AS `sss_no`,
       (select distinct `motorph_db`.`deductions`.`amount`
        from `motorph_db`.`deductions`
        where ((`motorph_db`.`deductions`.`payroll_id` = `motorph_db`.`payroll`.`payroll_id`) and
               (`motorph_db`.`deductions`.`deduction_code` = 'SSS')))                          AS `sss`,
       `motorph_db`.`employee_government_ids`.`phil_health_no`                                 AS `phil_health_no`,
       (select distinct `motorph_db`.`deductions`.`amount`
        from `motorph_db`.`deductions`
        where ((`motorph_db`.`deductions`.`payroll_id` = `motorph_db`.`payroll`.`payroll_id`) and
               (`motorph_db`.`deductions`.`deduction_code` = 'PHIC')))                         AS `philhealth`,
       `motorph_db`.`employee_government_ids`.`pag_ibig_no`                                    AS `pag_ibig_no`,
       (select distinct `motorph_db`.`deductions`.`amount`
        from `motorph_db`.`deductions`
        where ((`motorph_db`.`deductions`.`payroll_id` = `motorph_db`.`payroll`.`payroll_id`) and
               (`motorph_db`.`deductions`.`deduction_code` = 'HDMF')))                         AS `pag_ibig`,
       `motorph_db`.`employee_government_ids`.`tin_no`                                         AS `tin_no`,
       (select distinct `motorph_db`.`deductions`.`amount`
        from `motorph_db`.`deductions`
        where ((`motorph_db`.`deductions`.`payroll_id` = `motorph_db`.`payroll`.`payroll_id`) and
               (`motorph_db`.`deductions`.`deduction_code` = 'TAX')))                          AS `tax`
from (((`motorph_db`.`deductions` join `motorph_db`.`payroll` on ((`motorph_db`.`payroll`.`payroll_id` =
                                                                   `motorph_db`.`deductions`.`payroll_id`))) join `motorph_db`.`employee`
       on ((`motorph_db`.`payroll`.`employee_id` =
            `motorph_db`.`employee`.`employee_id`))) join `motorph_db`.`employee_government_ids`
      on ((`motorph_db`.`payroll`.`employee_id` = `motorph_db`.`employee_government_ids`.`employee_id`)))
group by `motorph_db`.`deductions`.`payroll_id`;

