create
    definer = admin@`%` procedure insert_employee_full_details(IN p_last_name varchar(255),
                                                               IN p_first_name varchar(255), IN p_date_of_birth date,
                                                               IN p_address varchar(255), IN p_contact_no varchar(20),
                                                               IN p_sss_no varchar(20), IN p_philhealth_no varchar(20),
                                                               IN p_pagibig_no varchar(20), IN p_tin_no varchar(20),
                                                               IN p_department_name varchar(255),
                                                               IN p_position_name varchar(255),
                                                               IN p_supervisor_name varchar(255),
                                                               IN p_status varchar(15), IN p_basic_salary decimal(8, 2),
                                                               IN p_rice_subsidy decimal(10, 2),
                                                               IN p_phone_allowance decimal(10, 2),
                                                               IN p_clothing_allowance decimal(10, 2),
                                                               IN p_semi_monthly decimal(10, 2),
                                                               IN p_hourly_rate decimal(5, 2))
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;

  -- Insert into employee table
  INSERT INTO employee (last_name, first_name, date_of_birth, address)
  VALUES (p_last_name, p_first_name, p_date_of_birth, p_address);

  -- Get the newly inserted employee_id
  SET @employee_id = LAST_INSERT_ID();

  -- Insert into employee_contact table
  INSERT INTO employee_contact (employee_id, contact_no)
  VALUES (@employee_id, p_contact_no);

  -- Insert into employee_government_ids table
  INSERT INTO employee_government_ids (employee_id, sss_no, philhealth_no, pagibig_no, tin_no)
  VALUES (@employee_id, p_sss_no, p_philhealth_no, p_pagibig_no, p_tin_no);

  -- Insert into department table if not exists
  IF NOT EXISTS (SELECT 1 FROM department WHERE department_name = p_department_name) THEN
    INSERT INTO department (department_name) VALUES (p_department_name);
  END IF;

  -- Get the department_code
  SET @department_code = (SELECT department_code FROM department WHERE department_name = p_department_name);

  -- Insert into position table if not exists
  IF NOT EXISTS (SELECT 1 FROM position WHERE position_name = p_position_name) THEN
    INSERT INTO position (position_name) VALUES (p_position_name);
  END IF;

  -- Get the position_code
  SET @position_code = (SELECT position_code FROM position WHERE position_name = p_position_name);

  -- Insert into employee_job_details table
  INSERT INTO employee_job_details (employee_id, supervisor_id, department_code, position_code, status_id)
  VALUES (@employee_id, (SELECT employee_id FROM employee WHERE CONCAT(last_name, ', ', first_name) = p_supervisor_name), @department_code, @position_code, (SELECT status_id FROM employment_status WHERE status = p_status));

  -- Insert into salary table
  INSERT INTO salary (employee_id, basic_salary, hourly_rate)
  VALUES (@employee_id, p_basic_salary, p_hourly_rate);

  -- Insert into benefits table
  INSERT INTO benefits (employee_id, benefit_type_id, amount)
  VALUES (@employee_id, 1, p_rice_subsidy),
         (@employee_id, 2, p_phone_allowance),
         (@employee_id, 3, p_clothing_allowance);

  COMMIT;
END;

