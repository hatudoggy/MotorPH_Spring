create definer = admin@`%` view employee_attendance as
select concat(`motorph_db`.`attendance`.`date`, '-', `motorph_db`.`attendance`.`employee_id`)  AS `attendance_id`,
       `motorph_db`.`attendance`.`date`                                                        AS `date`,
       `motorph_db`.`attendance`.`employee_id`                                                 AS `employee_id`,
       concat(`motorph_db`.`employee`.`last_name`, ', ', `motorph_db`.`employee`.`first_name`) AS `full_name`,
       `motorph_db`.`attendance`.`time_in`                                                     AS `time_in`,
       `motorph_db`.`attendance`.`time_out`                                                    AS `time_out`,
       round((case
                  when (`motorph_db`.`attendance`.`time_out` is not null) then (case
                                                                                    when (
                                                                                        `motorph_db`.`attendance`.`time_out` >=
                                                                                        `motorph_db`.`attendance`.`time_in`)
                                                                                        then (timestampdiff(MINUTE,
                                                                                                            `motorph_db`.`attendance`.`time_in`,
                                                                                                            `motorph_db`.`attendance`.`time_out`) /
                                                                                              60.0)
                                                                                    else (timestampdiff(MINUTE,
                                                                                                        `motorph_db`.`attendance`.`time_in`,
                                                                                                        addtime(`motorph_db`.`attendance`.`time_out`, '24:00:00')) /
                                                                                          60.0) end)
                  else NULL end), 2)                                                           AS `hours_worked`,
       (case
            when (cast(`motorph_db`.`attendance`.`time_out` as char charset utf8mb4) > '17:00:00') then (
                time_to_sec(timediff(`motorph_db`.`attendance`.`time_out`, '17:00:00')) / 3600)
            else 0 end)                                                                        AS `overtime_hours`
from (`motorph_db`.`attendance` join `motorph_db`.`employee`
      on ((`motorph_db`.`attendance`.`employee_id` = `motorph_db`.`employee`.`employee_id`)));

